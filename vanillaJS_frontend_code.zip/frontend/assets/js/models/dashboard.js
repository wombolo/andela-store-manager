class dashboard {

  static getMySales(){

  }
}